package tedking.luckymoney;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;
// 此类继承自NotificationListenerService,功能为读取通知栏消息，根据是否“[微信红包]”字样来确定是否有红包消息
public class NotificationClass extends NotificationListenerService {
    @Override
    //此方法必须重写，当通知栏消息改变时触发
    public void onNotificationPosted(StatusBarNotification sbn){
        Notification notification = sbn.getNotification();
        if (null == notification) return;

        Bundle extras = notification.extras;
        if (null == extras) return;

        List<String> textList = new ArrayList<>();
        String title = extras.getString("android.title");
        if (!isEmpty(title)) textList.add(title);

        String detailText = extras.getString("android.text");
        if (!isEmpty(detailText)) textList.add(detailText);

        if (textList.size() == 0) return;
        //for循环，遍历textList获取红包消息的notification，取到里面的PendingIntent执行
        for (String text : textList) {
            if (!isEmpty(text) && text.contains("[微信红包]")) {
                final PendingIntent pendingIntent = notification.contentIntent;
                try {
                    pendingIntent.send();
                } catch (PendingIntent.CanceledException e) {
                }
                break;
            }
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {

    }
}
