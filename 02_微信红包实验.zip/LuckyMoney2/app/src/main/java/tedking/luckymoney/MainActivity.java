package tedking.luckymoney;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;
//MainActivity,包括控件的获取，点击事件的处理，权限的检测，
public class MainActivity extends AppCompatActivity {
    private Button helper, notification;
    private TextView mAccessibleLabel,mLabelText,mNotificationLabel;
    private static final Intent sSettingsIntent =
            new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findView();
        //为启用辅助功能和允许读取通知两个button设置监听器，点击则跳到对应的设置界面
        helper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(sSettingsIntent);
            }
        });
        notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
            }
        });
    }
    @Override
    //activity获得焦点时调用
    protected void onResume() {
        super.onResume();
        changeLabelStatus();
    }

    //检测相应权限是否开启，在oncreate()中调用
    public void changeLabelStatus(){
        boolean isAccessibilityEnabled = isHelperEnable();
        mAccessibleLabel.setTextColor(isAccessibilityEnabled ? 0xFF009588 : Color.RED);
        mAccessibleLabel.setText(isAccessibilityEnabled ? "辅助功能已打开" : "辅助功能未打开");
        mLabelText.setText(isAccessibilityEnabled ? "自动抢红包功能已开启" : "请打开开关开始抢红包");

        boolean isNotificationEnabled = isNotificationEnabled();
        mNotificationLabel.setTextColor(isNotificationEnabled ? 0xFF009588 : Color.RED);
        mNotificationLabel.setText(isNotificationEnabled ? "接收通知已打开" : "接收通知未打开");

        if (isAccessibilityEnabled && isNotificationEnabled) {
            mLabelText.setText("成功开启自动抢红包功能");
        } else {
            mLabelText.setText("请把两个开关都打开开始抢红包");
        }
    }

    //各控件的findview，在oncreate()中调用
    private void findView(){
        helper = (Button) findViewById(R.id.helper);
        notification = (Button) findViewById(R.id.notification);
        mAccessibleLabel = (TextView) findViewById(R.id.text1);
        mNotificationLabel = (TextView) findViewById(R.id.text2);
        mLabelText = (TextView) findViewById(R.id.text3);

    }

    //检测辅助功能是否开启，是则返回true，否则返回false，在changeLabelStatus()方法中调用
    public boolean isHelperEnable(){
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> runningServices = manager.getEnabledAccessibilityServiceList(AccessibilityEvent.TYPES_ALL_MASK);
        for (AccessibilityServiceInfo info : runningServices) {
            if (info.getId().equals(getPackageName() + "/.MyService")) {
                return true;
            }
        }
        return false;
    }

    //检测是否允许读取通知，是则返回true，否则返回false，在changeLabelStatus()方法中调用
    private boolean isNotificationEnabled() {
        ContentResolver contentResolver = getContentResolver();
        String enabledListeners = Settings.Secure.getString(contentResolver, "enabled_notification_listeners");

        if (!TextUtils.isEmpty(enabledListeners)) {
            return enabledListeners.contains(getPackageName() + "/" + getPackageName() + ".NotificationClass");
        } else {
            return false;
        }
    }
}
